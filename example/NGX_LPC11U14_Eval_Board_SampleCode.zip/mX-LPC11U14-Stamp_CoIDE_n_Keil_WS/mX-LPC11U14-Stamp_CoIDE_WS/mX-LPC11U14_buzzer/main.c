void Buzzer();

int main(void)
{

    //automatically added by CoIDE
	Buzzer();

	while(1)
    {
    }
}

