#include "lcd.h"

void BlinkExp();
void ADCExp();

int main(void)
{

	init_lcd();						// Initialize LCD
	lcd_putstring(LINE1,"NGX TECHNOLOGIES");
    //automatically added by CoIDE
	ADCExp();

	//automatically added by CoIDE
	while(1)
    {
    }
}

