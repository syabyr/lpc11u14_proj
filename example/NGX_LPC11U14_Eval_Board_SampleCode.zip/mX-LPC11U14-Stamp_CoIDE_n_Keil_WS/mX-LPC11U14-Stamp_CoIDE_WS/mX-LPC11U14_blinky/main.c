void BlinkExp();

int main(void)
{

    //automatically added by CoIDE
	BlinkExp();

	while(1)
    {
    }
}

